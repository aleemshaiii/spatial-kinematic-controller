"""Optional diagnostics surfaces."""
