"""Bounded asynchronous output dispatch."""
